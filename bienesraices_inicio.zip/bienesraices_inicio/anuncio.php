<?php 
    // echo "<pre>";
    // var_dump($_GET);
    // echo "</pre>";

    //id de la propiedad
    $id = $_GET['id'];
    $id = filter_var($id, FILTER_VALIDATE_INT);

    if(!$id){
        header('Location: /bienesraices_inicio/');
    }

    //REQUIRE PARA LAS FUNCIONES O CODIGO COMPLEJO
    require 'includes/funciones.php';

    //$inicio = true; //DECLARAMOS UNA VARIABLE Y LA EVALUAMOS DENTRO DEL INCLUDE SIGUIENTE
    incluirTemplates('header'); //funcion extraida de require

    //IMPORTAR CONEXION 
    require __DIR__.'\includes\config\database.php';//otra forma de conectar
    $db = conectarDB();
    //CONSULTA
    $query = "SELECT * FROM propiedades WHERE id = ${id}";
    //RESULTADO
    $resultado = mysqli_query($db, $query);

    //validar que exista un resultado
    // echo "<pre>";
    // echo var_dump($resultado->num_rows);//RESULTADO ES UN OBJETO, PARA ACCEDER A LAS PRIEDADES DE  UN OBJETO UTILIZAMOS LA SINTAXIS DE FLECHA Y EL NOMBRE SIN COMILLAS
    // echo "</pre>";
    if(!$resultado->num_rows){
        header('Location:/bienesraices_inicio/');
    }

    $propiedad = mysqli_fetch_assoc($resultado);

    // echo "<pre>";
    // var_dump($propiedad);
    // echo "</pre>";
?>

    <main class="contenedor seccion contenido-centrado">
        <h1> <?php echo $propiedad['titulo']?> </h1>

        <img src="imagenes/<?php echo $propiedad['imagen']?> " alt="Imgaen destacada de la propiedad" loading="lazy">


        <div class="resumen-propiedad">
            <p class="precio">$<?php echo $propiedad['precio']?> </p>

            <ul class="iconos-caracteristicas">
                <li class="wc">
                    <img class="iconos-ventas" src="build/img/icono_wc.svg" alt="baños disponibles" loading="lazy">
                    <p> <?php echo $propiedad['wc']?> </p>
                </li>
                <li class="cocheras">
                    <img class="iconos-ventas" src="build/img/icono_estacionamiento.svg" alt="cocheras disponibles">
                    <p> <?php echo $propiedad['estacionamiento']?> </p>
                </li>
                <li class="recamaras">
                    <img class="iconos-ventas" src="build/img/icono_dormitorio.svg" alt="recamaras disponibles">
                    <p> <?php echo $propiedad['habitaciones']?> </p>
                </li>
            </ul>

            <p> <?php echo $propiedad['descripcion']?> </p>
        </div>
    </main>

<?php 
    //cerrar conecion
    mysqli_close($db);
    incluirTemplates('footer'); 
?>