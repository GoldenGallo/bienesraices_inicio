<?php

//IMPORTAR CONEXXION
require 'includes/config/database.php';
$db = conectarDB();

//email y password
$email = 'admin@admin.com';
$password =  '123456';

//PASSWORDHASH PROTEGE NUESTRAS CONTRASEÑAS ALMACENADAS EN LA BASE DE DATOS
//IMPORTANTE: HASS GENERA UN TOTAL DE 60 CARACTERES SIEMPRE ES POR ESO QUE EN NUESTRA BASE DE DATOS EL CAMPO PASSWORD DEBE CONTENER CHAR(60) YA QUE ES UNA CONSTANTE
$passwordHash = password_hash($password, PASSWORD_DEFAULT);

//consulta
$query = "INSERT INTO usuarios(email, password) VALUES ('${email}', '${passwordHash}')";

echo $query;

exit;

//agregarlo a la base de datos
mysqli_query($db, $query);