<?php 
    //REQUIRE PARA LAS FUNCIONES O CODIGO COMPLEJO
    require '../includes/funciones.php';
    $auth=estaAutenticado(); //esta funcion retorna true/flase
    if(!$auth){
        header('Location:/bienesraices_inicio/');
    }

// echo "<pre>";
// var_dump($_POST);
// echo "</pre>";

    //CONSULTA DE PROPIEDADES
    //IMPORTAR LA BASE DE DATOS
    require '../includes/config/database.php';
    $db = conectarDB();

    //QUERY O CODIGO SQL
    $query = "SELECT * FROM propiedades";

    //CONULSTAR BASE DE DATOS
    $resultadoConsulta = mysqli_query($db, $query);

    //FIN CONSULTA DE PROPIEDADES

    //mensaje condicional
    //PARA MOSTRAR UNA ALERTA DESPUES DE AVER INGRESADO UN VALOR ALA BASE DE DATOS LEEMOS EL VALOR ENVIADO POR LA URL
    $resultado = $_GET['resultado'] ?? null; //?? NULL SI LA VARIBLE NO CONTIENE UN VALOR LE ASIGNA NULL TAMBIEN SE PUEDE APLICA EL METODO ISSET

    //ELIMINAR
    //METODO METHOD DE LA PAGINA (CUANDO EL USUARIO ENVIE EL FORULARIO DE ELIMINAR)
    if($_SERVER['REQUEST_METHOD'] === 'POST'){//CUANDIO SE ENVIEN LOS DATOS POR EL METODO POST ENTONCES:
        $id = $_POST['id'];
        $id = filter_var($id, FILTER_VALIDATE_INT);

        if($id){
            //ELIMINAR ARCHIVO
            $query = "SELECT imagen FROM propiedades WHERE id = ${id}"; //buscamos el nombre de la imagen

            $resultado = mysqli_query($db, $query);//consultaos en la base de datos
            $eliminarArchivo = mysqli_fetch_assoc($resultado);//nombre dle archivo a eliminar

            unlink('../imagenes/'.$eliminarArchivo['imagen']); //borramos archivo

            //ELIMINAR PROPIEDAD
            $query = "DELETE FROM propiedades WHERE id = ${id}";
            // echo $query;
            $resultado = mysqli_query($db, $query);

            if($resultado){
                header('Location: /bienesraices_inicio/admin?resultado=3');
            }
        }
// echo "<pre>";
// var_dump($_POST);
// echo "</pre>";
// echo "<pre>";
// var_dump($_POST['id']);
// echo "</pre>";
    }

    
    //incluye el templates
    //$inicio = true; //DECLARAMOS UNA VARIABLE Y LA EVALUAMOS DENTRO DEL INCLUDE SIGUIENTE
    incluirTemplates('header'); //funcion extraida de require
?>

    <main class="contenedor seccion">
        <h1>Administrador de Bienes Raices</h1>
        
        <?php if(intval($resultado) === 1):/*INTVAL CONVIERTE LA VARIABLE QUE VIENE COMO STRING POR DEFECTO A VALOR ENTERO PARA SER EVALUADO CON ===*/?>
            <p class="alerta exito">Se creo una nueva propiedad</p>
        <?php endif;?>
        <?php if(intval($resultado) === 2):?>
            <p class="alerta exito">Se Actualizo correctamente la propiedad</p>
        <?php endif;?>
        <?php if(intval($resultado) === 3):?>
            <p class="alerta exito">Se Elimino correctamente la propiedad</p>
        <?php endif;?>

        <a href="/bienesraices_inicio/admin/propiedades/crear.php" class="boton boton-verde-inline-block">Crear Nueva Proiedad</a>

        <table class="propiedades">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Titulo</th>
                    <th>Imagen</th>
                    <th>Precio</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <!-- MOSTRAMOS LAS FILAS DE LA CONSULTA -->
                <?php while($propiedad = mysqli_fetch_assoc($resultadoConsulta)):?>
                <tr>
                    <td> <?php echo $propiedad['id'] ?> </td>
                    <td> <?php echo $propiedad['titulo']?> </td>
                    <td><img src="/bienesraices_inicio/imagenes/<?php echo $propiedad['imagen']?>" alt="imagen propiedad" class="imagen-tabla"></td>
                    <td>$ <?php echo $propiedad['precio']?></td>
                    <td>
                        <form method="POST" class="w-100"><!--ES ESTE FORMUARIO VA A ENVIAR LOS DATOS POR POST A ESTA MISMA PAGINA ES DECIR RECARGA LA PAGINA-->
                            <input type="hidden" name="id" value="<?php echo $propiedad['id']?>"><!--HIDDEN CAMPO CON UN VALOR INVISIBLE QUE SE PUEDE ENVIAR POR EL METODO DEL FORMULARIO-->
                            <input type="submit" class="boton-rojo-block" value="Eliminar"> <!--EL SUBMIT POR SI SOLO NO ENVIA NADA ES POR ESO QUE DEBEOS AGREGAR UN INPUT DE TYPE HIDDEN-->
                        </form>
                        <a href="/bienesraices_inicio/admin/propiedades/actualizar.php?id=<?php echo $propiedad['id']?>" class="boton-amarillo-block">Actualizar</a>
                    </td>
                </tr>
                <?php endwhile;?>
            </tbody>
        </table>
    </main>

<?php 
    mysqli_close($db);//OPCIONAL PERO ES RECOMENDABLE
    incluirTemplates('footer'); 
?>