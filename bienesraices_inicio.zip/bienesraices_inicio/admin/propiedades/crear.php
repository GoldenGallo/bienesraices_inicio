<?php 
    //REQUIRE PARA LAS FUNCIONES O CODIGO COMPLEJO
    require '../../includes/funciones.php';
    $auth=estaAutenticado(); //esta funcion retorna true/flase
    if(!$auth){
        header('Location:/bienesraices_inicio/');
    }

    //BASE DE DATOS
    require '../../includes/config/database.php';

    $db = conectarDB();

    /**
     * SI QUEREMOS LEER INFO DEL SERVIDOR Y TODOS SUS ATRIBUTOS*/
    //   echo "<pre>";
    //   var_dump($_SERVER['REQUEST_METHOD']);
    //   echo "</pre>";

    // CONSULTA PARA OBTENER LOS VENDEDORES
    $consulta = "SELECT * FROM vendedores;";
    $resultado = mysqli_query($db, $consulta);

    //ARREGLO CON MENSAJES DE ERRORES
    $errores = [];

    //SI QUEREMOS USAR LAS VARIABLES EN VALUES EN
    $titulo = '';
    $precio = '';
    $descripcion = '';
    $habitaciones = '';
    $wc = '';
    $estacionamiento = '';
    $vendedorId = '';
    $creado = date('Y-m-d'); //UTILIZAMOS LA FUNCION PARA ESTABLECER COMO FECHA DE CRAEACION LA ACTUAL

    //SI EL METODO DE CARGA ES POST ENTONCES VAMOS A LEER LOS VALORES
    //EJECUTAR EL CODIGO DESPUES DE QUE EL USUARIO ENVIA EL FORMULARIO
    if($_SERVER['REQUEST_METHOD'] === 'POST'){
        // echo "<pre>";
        // echo var_dump($_POST);
        // echo "</pre>";

        //PARA LEER EL CONTENIDO DE LOS ARCCHIVOS
        // echo "<pre>";
        // echo var_dump($_FILES);
        // echo "</pre>";

        //SANITIZAR
        // $numero = "1textomalo";
        // $numero2 = 2;

        //si sanitizamos la variable numero para que solo muestre datos enteros y no contenido malevolo usamos
        // $numeroSanitizado = filter_var($numero, FILTER_SANITIZE_NUMBER_INT);//el resultado solo mostraria valores enteros

        //validacion
        // $numeroSanitizado = filter_var($numero, FILTER_VALIDATE_EMAIL);//SI UN CORREO ESTA MAL ESCRITO O NO TIENE LA ESTRUCTURA DE UN CORREO RETORNA UN FALSE

        // var_dump($numeroSanitizado);

        // exit;

        $titulo = mysqli_real_escape_string($db, $_POST['titulo'] );
        $precio = filter_var($_POST['precio'], FILTER_VALIDATE_FLOAT);
        $descripcion = mysqli_real_escape_string($db, $_POST['descripcion'] );
        $habitaciones = mysqli_real_escape_string($db, $_POST['habitaciones'] );
        $wc = mysqli_real_escape_string($db, $_POST['wc'] );
        $estacionamiento = mysqli_real_escape_string($db, $_POST['estacionamiento'] );
        $vendedorId = mysqli_real_escape_string($db, $_POST['vendedor'] );
        $creado = mysqli_real_escape_string($db, $_POST['creado'] );

        $imagen = $_FILES['imagen'];
        //var_dump($imagen); PARA VER EL CONTENIDO QUE SE USARAN PARA VALIDAR LAS IMAGENES

        if(!$titulo){ //si la variable esta vacia
            $errores[] = "Debes ingresar un titulo a la propiedad";
        }
        if(!$precio){ //si la variable esta vacia
            $errores[] = "Debes ingresar un precio a la propiedad";
        }
        if( strlen($descripcion) < 50 ){ //si la variable es menor a 50 caracteres
            $errores[] = "Debes ingresar una descripcion de almenos 50 caracteres";
        }
        if(!$habitaciones){ //si la variable esta vacia
            $errores[] = "Debes ingresar el numero de habitaciones de la propiedad";
        }
        if(!$wc){ //si la variable esta vacia
            $errores[] = "Debes ingresar el numero de wc de la propiedad";
        }
        if(!$estacionamiento){ //si la variable esta vacia
            $errores[] = "Debes ingresar el numero de estacionamientos de la propiedad";
        }
        if(!$vendedorId){ //si la variable esta vacia
            $errores[] = "Elige un vendedor";
        }
        if(!$creado){ //si la variable esta vacia
            $errores[] = "Elige una fecha";
        }
        if(!$imagen['name']){ //si la variable esta vacia o es mayor a 2megas(limite de php) por que marca error
            $errores[] = "La imagen es obligatoria";
        }

        //VALIDAR EL TAMAÑO DE LA IMAGEN (1mb MAX) - SI QUEREMOS AGREGAR IMAGENES PESADAS Y EL PHP NO LO PERMITE POR ALGUNA CONFIGURACION DEL SISTEMA PHP DEBEMOS BUSCAR EL ARCHIVO PHP.INI Y MODIFICAR SIERTAS CONFIGURACIONES
        $medida = 1000*1000;

        if($imagen['size'] > $medida){
            $errores[] = "La imagen es muy pesada";
        }

        //REVISAR SI EL ARRAY ESTA VACIO Y SI TIENE VALORES ES POR QUE EXISTEN ERRORES
        if(empty($errores)){

            //SUBIDA DE ARCHIVOS

            //CREAMOS UNA CARPETA PARA ALMACENAR LAS IMAGENES
            $carpetaImagenes = '../../imagenes/';//COMO QUEREMOS CREAR LA CARPETA EN LA RAIZ DEL PROYECTO DEBE MOS SALIRNOS DE LAS CARPETAS EN LAS QUE ESTEMOS HASTA LLEGAR A LA RAIZ

            if(!is_dir($carpetaImagenes)){//SI LA CARPETA DE IMAGENES NO ESTA CREADA ENTONCES CREAMOS LA CARPETA
                mkdir($carpetaImagenes);
            }

            //GENERAMOS UN NOMBRE UNICO - este nombre es el que se almacena en la tabla
            $nombreImagen = md5( uniqid( rand(), true ) ).".jpg";//md5 toma un valor de entrada y genera un nombre aleatorio, uniqid genera un nombres diferentes

            //SUBIR IMAGENES Y AGREGARLAS ALA CARPETA PARA LAS IMAGENES
            move_uploaded_file($imagen['tmp_name'], $carpetaImagenes.$nombreImagen);

            //INSERTAR EN LA BASE DE DATOS
            $query = "INSERT INTO propiedades(titulo, precio, imagen, descripcion, habitaciones, wc, estacionamiento, creado, vendedorId) VALUES ('$titulo', '$precio', '$nombreImagen', '$descripcion', '$habitaciones', '$wc', '$estacionamiento', '$creado','$vendedorId') ";
        
            //COMPROBAMOS QUE SE INSRTARON LOS DATOS
            $resultado = mysqli_query($db, $query);
        
            if($resultado){
                // echo 'nuevo registro';
                header( 'Location: /bienesraices_inicio/admin?resultado=1&mensaje=metodoget'); //redireccionar si el formulario es correcto
            }
        }
    }

    //$inicio = true; //DECLARAMOS UNA VARIABLE Y LA EVALUAMOS DENTRO DEL INCLUDE SIGUIENTE
    incluirTemplates('header'); //funcion extraida de require
?>

    <main class="contenedor seccion">
        <h1>Crear</h1>

        <a href="/bienesraices_inicio/admin" class="boton boton-verde-inline-block">Volver</a>

        <!-- MOSTRAMOSLOS EL TEXTO QUE CONTIENE EL ARREGLO ES DECIR LOS ERRORES -->
        <?php foreach( $errores as $error ): ?>
            <div class="alerta error">
                <?php echo $error; ?>
            </div>
        <?php endforeach; ?>

        <!-- POST SE UTILIZA PARA PROCESAR DATOS DE FORMA SEGURA SIN EXPONER INFORMACION
            GET SE UTILIZA PARA ENVIARDATOS DE UNA VENTANA A OTRA POR MEDIO DE LA URL
        SIN EL NAME EN LOS INPUT LOS VALORES CON POST O GET NO SE ENVIAN-->
        <form action="/bienesraices_inicio/admin/propiedades/crear.php" class="formulario" method="POST" enctype="multipart/form-data">
            <fieldset>
                <legend>informacion General</legend>
    
                <label for="titulo">Titulo:</label>
                <input type="text" id="titulo" name="titulo" placeholder="Titulo de la propiedad" value="<?php echo $titulo; ?>"><!---LO QUE ESTA DENTRO DE VALUE MUESTRA EL VALOR QUE SE INGRESA DESPUES DE DAR CLICK EN SUBMIT DEL FORMULARIO-->
    
                <label for="precio">Precio:</label>
                <input type="text" id="precio" name="precio" placeholder="Precio de la propiedad" value="<?php echo $precio; ?>">
    
                <label for="imagen">Imagen:</label>
                <input type="file" id="imagen" accept="image/jpeg, image/png" name="imagen">
    
                <label for="descripcion">Descripcion:</label>
                <textarea id="descripcion" name="descripcion"> <?php echo $descripcion; ?> </textarea>
            </fieldset>

            <fieldset>
                <legend>Informacion de la propiedad</legend>

                <label for="habitaciones">Habitaciones:</label>
                <input type="text" id="habitaciones" name="habitaciones" placeholder="Ej: 3" min="1" max="9"  value="<?php echo $habitaciones; ?>">

                <label for="wc">Baños:</label>
                <input type="text" id="wc" name="wc" placeholder="Ej: 3" min="1" max="9" value="<?php echo $wc; ?>">

                <label for="estacionamiento">Estacionamiento:</label>
                <input type="text" id="estacionamiento" name="estacionamiento" placeholder="Ej: 3" min="1" max="9" value="<?php echo $estacionamiento; ?>">
            </fieldset>

            <fieldset>
                <legend>Vendedor</legend>

                <select name="vendedor">
                    <option value="" selected>--Selecciona un vendedor--</option>
                    <?php while( $row = mysqli_fetch_assoc($resultado) ):/**arreglo de resultados de la consulta**/ ?>
                        <option  <?php echo $vendedorId === $row['id']? 'selected': ''; ?> value="<?php echo $row['id']?>"> <?php echo $row['nombre']. " " . $row['apellido']?></option>
                        <!-- SI EL VENDEDORID ES IGAUL AL ID DE LA TABLA ENTONCES ASIGNAMOS UN SELECT DE CASO CONTRARIO NO(PARA MANTENER EL DATO QUE SE SELECCION DESPUES DE ENVIAR DATOS) -->
                    <?php endwhile;?>
                </select>
            </fieldset>

            <fieldset>
                <legend>Fecha de creaciond del registro</legend>

                <label for="creado">Creado:</label>
                <input type="date" name="creado" id="creado" value="<?php echo $creado ?>"> <!-- LEEMOS LA FECHA QUE YA SE ESTABLECIO -->
            </fieldset>

            <input type="submit" value="Crear propiedad" class="boton boton-verde-inline-block">
        </form>
    </main>

<?php incluirTemplates('footer'); ?>