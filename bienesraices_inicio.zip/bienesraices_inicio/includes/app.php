<?php
//constante para especificar la direccion de los templates
define('TEMPLATES_URL', __DIR__. '/templates'); //__DIR__ ES UNA VARIABLE GLOBAL Y OBTIENE LA RUTA EN LA QUE SE ENCUENTRA TEMPLATES
//UBICACION DE LAS FUNCIONES
define('FUNCIONES_URL', __DIR__.'funciones.php');