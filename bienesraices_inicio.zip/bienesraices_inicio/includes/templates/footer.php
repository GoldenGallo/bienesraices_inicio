<footer class="seccion footer">
        <div class="contenedor contenedor-footer">
            <nav class="navegacion">
                <a href="nosotros.php">Nosotros</a>
                <a href="anuncios.php">Anuncios</a>
                <a href="blog.php">Blog</a>
                <a href="contacto.php">Contacto</a>
            </nav>
        </div>

        <?php //$fecha = date('d-m-y'); echo $fecha; //funcion para capturar la fecha actual ?>

        <p class="copyright">Todos los derechos reservados <?php echo date('Y')?> &copy;</p>
    </footer>

    <script src="/bienesraices_inicio/build/js/bundle.min.js"></script>
</body>
</html>