<?php
    // var_dump($_SESSION);
    if(!isset($_SESSION)){//si NO esta definida entonces no esta activado el session_start entonces
        session_start();
        // var_dump($_SESSION);
    }

    //usamos la variable para revisar si el login qesta activado es decir la secion activa
    $auth = $_SESSION['login'] ?? false;

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bienes Raizes</title>
    <link rel="stylesheet" href="/bienesraices_inicio/build/css/app.css">
</head>
<body>
    <header class="header invisible <?php echo $inicio ? 'inicio' : ''; /*ESTO ES UNA CONDICIO SIMILAR AL IF SI $INICIO ES TRUE COLOCA LA 'INICIO' QUE ES LA CLASE QUE TIENE LA IMAGEN DEL HEADER EN EL INDEX*/  ?>">
        <div class="contenedor contenido-header">
            <div class="barra">
                <a href="index.php">
                    <img src="/bienesraices_inicio/build/img/logo.svg" alt="Logo bienes raizes">
                </a>

                <div class="mobile-menu">
                    <img src="/bienesraices_inicio/build/img/barras.svg" alt="icono menu">
                </div>

                <div class="menu-derecha">
                    <img src="/bienesraices_inicio/build/img/dark-mode.svg" class="dark-mode-boton">
                    <nav class="navegacion">
                        <a href="nosotros.php">Nosotros</a>
                        <a href="anuncios.php">Anuncios</a>
                        <a href="blog.php">Blog</a>
                        <a href="contacto.php">Contacto</a>
                        <?php if($auth):?>
                            <a href="cerrar-sesion.php">Cerrar secion</a>
                        <?php endif;?>
                    </nav>
                </div>
            </div><!--CIERRE DE LA BARRA-->
            <h1 class="titulo-header">Venta de casas y departamentos exclusivos de lujo</h1>
            <!--TAMBIEN
            <?php
                //if($inicio){
                //    echo "<h1>Venta de casas y departamentos exclusivos de lujo</h1>";
                //}
            ?>
            -->
        </div>
    </header>