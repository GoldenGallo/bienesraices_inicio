<?php
    //IMPORTAR CONEXION
    require 'includes/config/database.php'; //DIRECCION RELATICVA AL DOC QUE LA MANDA A LLAMAR ES DECIR EN BASE A LA RUTA DEL INDEX Y ANUNCIOS
    $db = conectarDB();

    //CONUSLTA
    $query = "SELECT * FROM propiedades LIMIT ${limit}";

    //OBTENER RESULTADO DE CONSULTA
    $resultado = mysqli_query($db, $query);
?>

<div class="contenedor-anuncios">
    <?php while($propiedad = mysqli_fetch_assoc($resultado)):?>
        <div class="anuncio">

        <div class="img">
            <img src="imagenes/<?php echo $propiedad['imagen']?>" alt="Casas y depas en ventas" loading="lazy">
        </div>

            <div class="contenido-anuncio"> 
                <h3 class="nombre"><?php echo $propiedad['titulo']?></h3>
                <p  class="descripcion"><?php echo $propiedad['descripcion']?></p>
                <p  class="precio">$<?php echo $propiedad['precio']?></p>
                <ul class="iconos-caracteristicas">
                    <li>
                        <img class="iconos-ventas" src="build/img/icono_wc.svg" alt="baños disponibles" loading="lazy">
                        <p><?php echo $propiedad['wc']?></p>
                    </li>
                    <li>
                        <img class="iconos-ventas" src="build/img/icono_estacionamiento.svg" alt="cocheras disponibles">
                        <p><?php echo $propiedad['estacionamiento']?></p>
                    </li>
                    <li>
                        <img class="iconos-ventas" src="build/img/icono_dormitorio.svg" alt="recamaras disponibles">
                        <p><?php echo $propiedad['habitaciones']?></p>
                    </li>
                </ul >
                <a href="anuncio.php?id=<?php echo $propiedad['id']?>" class="boton-amarillo-block">Ver propiedad</a>
            </div><!--CONTENIDO-ANUNCIO-->
        </div> <!--FIN ANUNCIO-->
    <?php endwhile;?>
</div><!--FIN CONTENEDOR-ANUNCIOS-->

<?php
    //CERRAR CONEXION
    mysqli_close($db);
?>