<?php

require 'app.php';

function incluirTemplates( string $nombre , bool $inicio = false){
    // echo TEMPLATES_URL ."/${nombre}.php"; Si queremos imprimir la ruta
    include TEMPLATES_URL ."/${nombre}.php"; //LLAMAMOS A LA VARIABLE QUE SE ENCUENTRA EN APP.PHP LA VARIABLE SE DECLARA EN COMILLAS Y SE UTILIZA SIN ELLAS
}

function estaAutenticado() : bool{
    session_start();//INICIAR SECION

    // echo "<pre>";
    // var_dump($_SESSION);
    // echo "</pre>";

    $auth = $_SESSION['login']; // SI LA SESION ESTA ACTIVA ENTONCES LOGIN DE LA SUPERGLOBAL ES TRUE
    if($auth){
        return true;
    }
    return false;
}