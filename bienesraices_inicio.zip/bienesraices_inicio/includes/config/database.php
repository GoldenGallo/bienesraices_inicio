<?php 

function conectarDB() : mysqli{
    $db = mysqli_connect('localhost', 'root', '', 'bienes_raices');

    if(!$db){
        echo 'conexion fallida';
        exit;
    }
    return $db;
}