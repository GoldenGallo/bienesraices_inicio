<?php 
    //importar base de datos
    require 'includes/config/database.php';
    $db = conectarDB();

    $errores = [];

    //VALIDAR USUARIO
    if($_SERVER['REQUEST_METHOD'] === 'POST'){
        // echo "<pre>";
        // var_dump($_POST);
        // echo "</pre>";
        // exit;
        //SANITISAMOS LOS DATOS QUE ENTRAN EN LA BASE DE DATOS
        $email = mysqli_real_escape_string($db, filter_var($_POST['email'], FILTER_VALIDATE_EMAIL));
        //                                 FILTRAMOS LOS DATOS ESCRITOS
        $password = mysqli_real_escape_string($db, $_POST['password']);

        if(!$email){
            $errores[] = "El email es obligatorio o no es valido";
        }
        if(!$email){
            $errores[] = "La contraseña es obligatorio";
        }

        if(empty($errores)){//si errores esta vacio entonces

            //revisar si el usuario existe
            $query = "SELECT * FROM usuarios WHERE email = '${email}' ";
            $resultado = mysqli_query($db, $query);

            // var_dump($resultado);

            if($resultado->num_rows){// si la consulta contiene un resultado (usuario existente) entonces:
                //revisar si el password es correcto
                $usuario = mysqli_fetch_assoc($resultado); //arreglo de los datos de la consulta
                // var_dump($usuario); 
                //verificar si el password es correcto o no - FUNCION DE PHP QUE DEVUELVE TRUE O FALSE SI LA CONTRASEÑA ESCRITA ES CORRECTA O NO
                $auth = password_verify($password, $usuario['password']); //REQUIERE DE EL PASSWORD ESCRITO EN ESTE FORMULARIO Y EL QUE SE ENCUENTRA EN LA BASE DE DATOS

                if($auth){
                    //EL USUARIO ESTA AUTENTICADO
                    session_start();//super global que inidia que la secion esta abierta

                    //llenar el arreglo de la secion (ESTE ARREGLO PUEDE CONTENER CUALQUIER INFORMACION, E INFORMACION DESDE LA BASE DEDATOS Y USARLA EN LAS CUALQUIERA DE LAS PAGINAS)
                    $_SESSION['usuaro'] = $usuario['email'];
                    $_SESSION['login'] = true;
                    //ESTOS DATOS ESTARAN DISPONIBLES MIENTRAS SESSION_START ESTE ACTIVO

                    // echo "<pre>";
                    // var_dump($_SESSION);
                    // echo "</pre>";

                    header('Location:/bienesraices/admin/');
                }else{
                    $errores[] = 'Contraseña incorrecta';
                }

            }else{ //si no se encuentra el correo en la base de datos
                $errores[] = "Este usuario no registrado";
            }

        }
    }

    //incluye el header
    //REQUIRE PARA LAS FUNCIONES O CODIGO COMPLEJO
    require 'includes/funciones.php';

    //$inicio = true; //DECLARAMOS UNA VARIABLE Y LA EVALUAMOS DENTRO DEL INCLUDE SIGUIENTE
    incluirTemplates('header'); //funcion extraida de require
?>

    <main class="contenedor seccion contenido-centrado">
        <h1>Iniciar Seción</h1>

        <?php foreach($errores as $error): ?>
            <div class="alerta error">
                <?php echo $error;?>
            </div>
        <?php endforeach;?>

        <form class="formulario" method="POST">
            <fieldset>
                <legend>Email y Contraseña</legend>
                <label for="email">Email:</label>
                <input type="email" placeholder="Tu correo electronico" name="email" id="email" require>
                <label for="password">Contraseña:</label>
                <input type="password" placeholder="Tu contraseña" id="password" name="password" require>
            </fieldset>
            
            <input type="submit" value="Iniciar seción" class="boton boton-verde-inline-block">
        </form>

    </main>

<?php incluirTemplates('footer'); ?>