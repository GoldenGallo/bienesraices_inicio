<?php 
    //REQUIRE PARA LAS FUNCIONES O CODIGO COMPLEJO
    require 'includes/funciones.php';

    //$inicio = true; //DECLARAMOS UNA VARIABLE Y LA EVALUAMOS DENTRO DEL INCLUDE SIGUIENTE
    incluirTemplates('header'); //funcion extraida de require
?>

    <main class="contenedor seccion contenido-centrado">
        <h1>Casa en venta frente al bosque</h1>

        <picture>
            <source srcset="build/img/destacada2.webp" type="image/webp">
            <source srcset="build/img/destacada2.jpg" type="image/jpeg">
            <img src="build/img/destacada2.jpg" alt="Imgaen destacada de la propiedad" loading="lazy">
        </picture>

        <p class="informacion-meta">Escrito el: <span>20/02/2022</span>, por: <span>Admin</span></p>

        <div class="resumen-propiedad">
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Minus molestias adipisci rerum, soluta totam tempore odio ipsa architecto possimus vitae natus incidunt quae! Iusto delectus natus dicta aliquid voluptatibus aperiam. Lorem ipsum dolor sit amet consectetur adipisicing elit. Rem ipsam maxime nemo porro pariatur sapiente quasi a corporis ea inventore sequi nisi tempore quod explicabo possimus expedita, voluptas facere id!</p>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptas doloremque voluptatum ullam est facilis iste placeat numquam suscipit culpa, ea architecto esse labore unde dolore amet perspiciatis magnam aperiam odio?</p>
        </div>
    </main>

<?php incluirTemplates('footer'); ?>