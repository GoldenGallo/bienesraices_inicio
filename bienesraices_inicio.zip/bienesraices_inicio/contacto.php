<?php 
    //REQUIRE PARA LAS FUNCIONES O CODIGO COMPLEJO
    require 'includes/funciones.php';

    //$inicio = true; //DECLARAMOS UNA VARIABLE Y LA EVALUAMOS DENTRO DEL INCLUDE SIGUIENTE
    incluirTemplates('header'); //funcion extraida de require
?>

    <main class="contenedor seccion">
        <h1>Contacto</h1>

        <picture>
            <source srcset="build/img/destacada3.webp" type="image/webp">
            <source srcset="build/img/destacada3.jpg" type="image/jpeg">
            <img src="build/img/destacada3.jpg" alt="Encabezado formulario" loading="lazy">
        </picture>

        <h2>Llene el fomrmulario de contacto</h2>

        <form action="" class="formulario">
            <fieldset>
                <legend>Informacion personal</legend>
                <label for="nombre">Nombre:</label>
                <input type="text" id="nombre" placeholder="Ingresa tu nombre">

                <label for="email">E-mail:</label>
                <input type="email" id="nombre" placeholder="Ingresa tu email">

                <label for="telefono">Telefono:</label>
                <input type="tel" id="telefono" placeholder="Ingresa tu telefono">

                <label for="mensaje">Mensaje:</label>
                <textarea name="" id="mensaje"></textarea>
            </fieldset>

            <fieldset>
                <legend>Informacion sobre la propiedad</legend>
                <label for="opciones">Vende o compra:</label>
                <select name="" id="opciones">
                    <option value="" disabled selected>-- Seleccione --</option>
                    <option value="Compra">Compra</option>
                    <option value="Vende">Vende</option>
                </select>

                <label for="presupuesto">Precio o presupuesto:</label>
                <input type="number" placeholder="Tu precio o presupuesto" id="presupuesto"> 
            </fieldset>

            <fieldset>
                <legend>Contacto</legend>
                <p>Como desea ser contactado</p>

                <div class="forma-contacto">
                    <label for="contactar-telefono">Telefono:</label>
                    <input name="contacto" id="contactar-telefono" type="radio" value="telefono">
                    <label for="contactar-email">E-mail:</label>
                    <input name="contacto" id="contactar-email" type="radio" value="email">
                </div>

                <p>Si eligio telefono, eliga la fecha y hora</p>
                <label for="fecha">Fecha:</label>
                <input type="date" id="fecha">

                <label for="hora">Hora:</label>
                <input type="time" id="hora" min="09:00" max="10:00">
            </fieldset>

            <input type="submit" value="Enviar" class="boton-verde-inline-block">
        </form>
    </main>
<?php incluirTemplates('footer'); ?>