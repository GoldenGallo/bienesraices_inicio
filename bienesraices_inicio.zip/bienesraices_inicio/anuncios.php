<?php 
    //REQUIRE PARA LAS FUNCIONES O CODIGO COMPLEJO
    require 'includes/funciones.php';

    //$inicio = true; //DECLARAMOS UNA VARIABLE Y LA EVALUAMOS DENTRO DEL INCLUDE SIGUIENTE
    incluirTemplates('header'); //funcion extraida de require
?>

    <main class="contenedor seccion">
        <h1>Casas y depas en venta</h1>
        
        <?php 
            $limit = 10; //esta variable se envia a include
            include 'includes/templates/anuncios.php';
        ?>

    </main>

<?php incluirTemplates('footer'); ?>