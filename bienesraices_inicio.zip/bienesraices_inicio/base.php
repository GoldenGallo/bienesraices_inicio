<?php 
    //REQUIRE PARA LAS FUNCIONES O CODIGO COMPLEJO
    require 'includes/funciones.php';

    //$inicio = true; //DECLARAMOS UNA VARIABLE Y LA EVALUAMOS DENTRO DEL INCLUDE SIGUIENTE
    incluirTemplates('header'); //funcion extraida de require
?>

    <main class="contenedor seccion">
        <h1>titulo pagina</h1>
    </main>

<?php incluirTemplates('footer'); ?>