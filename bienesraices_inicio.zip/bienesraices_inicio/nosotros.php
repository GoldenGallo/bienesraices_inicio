<?php 
    //REQUIRE PARA LAS FUNCIONES O CODIGO COMPLEJO
    require 'includes/funciones.php';

    //$inicio = true; //DECLARAMOS UNA VARIABLE Y LA EVALUAMOS DENTRO DEL INCLUDE SIGUIENTE
    incluirTemplates('header'); //funcion extraida de require
?>

    <main class="contenedor seccion">
        <h1>Conoce sobre nosotros</h1>

        <div class="nosotros">
            <div class="imagen-nosotros">
                <picture>
                    <source srcset="build/img/nosotros.webp" type="image/webp">
                    <source srcser="build/img/nosotros.jpg" type="image/jpeg">
                    <img loading="lazy" src="build/img/nosotros.jpg" alt="Imagen sobre nosotros">
                </picture>
            </div>

            <div class="contenido-nosotros">
                <blockquote>23 años de emprendimiento</blockquote>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Minus molestias adipisci rerum, soluta totam tempore odio ipsa architecto possimus vitae natus incidunt quae! Iusto delectus natus dicta aliquid voluptatibus aperiam. Lorem ipsum dolor sit amet consectetur adipisicing elit. Rem ipsam maxime nemo porro pariatur sapiente quasi a corporis ea inventore sequi nisi tempore quod explicabo possimus expedita, voluptas facere id!</p>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptas doloremque voluptatum ullam est facilis iste placeat numquam suscipit culpa, ea architecto esse labore unde dolore amet perspiciatis magnam aperiam odio?</p>
            </div>
        </div>
    </main>

    <section class="contenedor seccion">
        <h1>Mas sobre nosotros</h1>

        <div class="iconos">
            <div class="icono">
                <img src="build/img/icono1.svg" alt="Icono seguridad" loading="lazy">
                <h3>Seguridad</h3>
                <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dicta, nobis consectetur ex porro tenetur expedita quaerat maxime illum sapiente deserunt dolor, numquam earum.</p>
            </div>
            <div class="icono">
                <img src="build/img/icono2.svg" alt="Icono precio" loading="lazy">
                <h3>Precio</h3>
                <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dicta, nobis consectetur ex porro tenetur expedita quaerat maxime illum sapiente deserunt dolor, numquam earum.</p>
            </div>
            <div class="icono">
                <img src="build/img/icono3.svg" alt="Icono tiempo" loading="lazy">
                <h3>A tiempo</h3>
                <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dicta, nobis consectetur ex porro tenetur expedita quaerat maxime illum sapiente deserunt dolor, numquam earum.</p>
            </div>
        </div>
    </section>

<?php incluirTemplates('footer'); ?>